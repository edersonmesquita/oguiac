<?php
/**
 * Middleware de autenticação JWT
 * Guia Canindé
 */

require_once __DIR__ . '/../helpers/jwt.php';
require_once __DIR__ . '/../helpers/response.php';

/**
 * Exige token JWT válido no header Authorization: Bearer <token>
 * Retorna o payload decodificado ou encerra com 401
 */
function requireAuth(): array {
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';

    if (!$header || !str_starts_with($header, 'Bearer ')) {
        respondError(401, 'Token não fornecido');
    }

    $token   = substr($header, 7);
    $payload = jwtDecode($token);

    if (!$payload) {
        respondError(401, 'Token inválido ou expirado');
    }

    return $payload;
}

/**
 * Exige que o usuário autenticado seja admin
 */
function requireAdmin(): array {
    $payload = requireAuth();

    if (($payload['role'] ?? '') !== 'admin') {
        respondError(403, 'Acesso restrito a administradores');
    }

    return $payload;
}

/**
 * Exige que seja uma empresa autenticada
 */
function requireCompany(): array {
    $payload = requireAuth();

    if (($payload['role'] ?? '') !== 'company') {
        respondError(403, 'Acesso restrito a empresas');
    }

    return $payload;
}
