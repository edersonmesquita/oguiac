<?php
/**
 * Controller de Avaliações
 * Guia Canindé
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../helpers/response.php';

function createRating(): void {
    $body = getJsonBody();

    if (empty($body['companyId']) || empty($body['stars'])) {
        respondError(400, 'companyId e stars são obrigatórios');
    }

    $stars = (int) $body['stars'];
    if ($stars < 1 || $stars > 5) {
        respondError(400, 'Stars deve ser entre 1 e 5');
    }

    $db = getDB();

    // Valida que empresa existe e está aprovada
    $check = $db->prepare("SELECT id FROM companies WHERE id = ? AND approved = 1");
    $check->execute([$body['companyId']]);
    if (!$check->fetch()) respondError(404, 'Empresa não encontrada');

    $id = generateUuid();
    $db->prepare("INSERT INTO ratings (id, stars, companyId, userId, createdAt, updatedAt) VALUES (?, ?, ?, ?, NOW(), NOW())")
       ->execute([$id, $stars, $body['companyId'], $body['userId'] ?? null]);

    respond(201, ['id' => $id, 'message' => 'Avaliação registrada']);
}

function getCompanyRatings(string $companyId): void {
    $db   = getDB();
    $stmt = $db->prepare("
        SELECT r.id, r.stars, r.createdAt, u.name AS userName
        FROM ratings r
        LEFT JOIN users u ON u.id = r.userId
        WHERE r.companyId = ?
        ORDER BY r.createdAt DESC
        LIMIT 50
    ");
    $stmt->execute([$companyId]);
    respond(200, $stmt->fetchAll());
}
