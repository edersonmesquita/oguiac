<?php
/**
 * Controller de Categorias
 * Guia Canindé
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../helpers/response.php';
require_once __DIR__ . '/../middleware/auth.php';

function getCategories(): void {
    $db   = getDB();
    $stmt = $db->query("
        SELECT
            cat.*,
            COUNT(c.id) AS companyCount
        FROM categories cat
        LEFT JOIN companies c ON c.categoryId = cat.id AND c.approved = 1
        GROUP BY cat.id
        ORDER BY cat.name ASC
    ");
    respond(200, $stmt->fetchAll());
}

function getCategory(string $id): void {
    $db   = getDB();
    $stmt = $db->prepare("
        SELECT cat.*, COUNT(c.id) AS companyCount
        FROM categories cat
        LEFT JOIN companies c ON c.categoryId = cat.id AND c.approved = 1
        WHERE cat.id = ?
        GROUP BY cat.id
    ");
    $stmt->execute([$id]);
    $cat = $stmt->fetch();
    if (!$cat) respondError(404, 'Categoria não encontrada');
    respond(200, $cat);
}

function createCategory(): void {
    requireAdmin();
    $body = getJsonBody();
    if (empty($body['name'])) respondError(400, 'Nome obrigatório');

    $db = getDB();

    // Edge case: categoria duplicada
    $check = $db->prepare("SELECT id FROM categories WHERE name = ?");
    $check->execute([sanitize($body['name'])]);
    if ($check->fetch()) respondError(409, 'Categoria já existe');

    $id = generateUuid();
    $db->prepare("INSERT INTO categories (id, name, description, createdAt, updatedAt) VALUES (?, ?, ?, NOW(), NOW())")
       ->execute([$id, sanitize($body['name']), $body['description'] ?? null]);

    respond(201, ['id' => $id, 'message' => 'Categoria criada']);
}

function updateCategory(string $id): void {
    requireAdmin();
    $body = getJsonBody();
    if (empty($body)) respondError(400, 'Nenhum dado enviado');

    $db   = getDB();
    $sets = [];
    $params = [];

    if (isset($body['name'])) {
        $sets[]   = 'name = ?';
        $params[] = sanitize($body['name']);
    }
    if (array_key_exists('description', $body)) {
        $sets[]   = 'description = ?';
        $params[] = $body['description'];
    }

    if (empty($sets)) respondError(400, 'Nenhum campo para atualizar');

    $params[] = $id;
    $db->prepare("UPDATE categories SET " . implode(', ', $sets) . ", updatedAt = NOW() WHERE id = ?")
       ->execute($params);

    respond(200, ['message' => 'Categoria atualizada']);
}

function deleteCategory(string $id): void {
    requireAdmin();
    $db = getDB();

    // Edge case: não pode deletar categoria com empresas vinculadas
    $check = $db->prepare("SELECT COUNT(*) FROM companies WHERE categoryId = ?");
    $check->execute([$id]);
    if ($check->fetchColumn() > 0) {
        respondError(409, 'Não é possível excluir categoria com empresas vinculadas');
    }

    $stmt = $db->prepare("DELETE FROM categories WHERE id = ?");
    $stmt->execute([$id]);
    if ($stmt->rowCount() === 0) respondError(404, 'Categoria não encontrada');

    respond(200, ['message' => 'Categoria removida']);
}
