<?php
/**
 * Controller do Dashboard Administrativo
 * Guia Canindé
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../helpers/response.php';
require_once __DIR__ . '/../middleware/auth.php';

function getDashboard(): void {
    requireAdmin();
    $db = getDB();

    // Contadores principais
    $totalCompanies   = (int) $db->query("SELECT COUNT(*) FROM companies")->fetchColumn();
    $totalCategories  = (int) $db->query("SELECT COUNT(*) FROM categories")->fetchColumn();
    $approvedCount    = (int) $db->query("SELECT COUNT(*) FROM companies WHERE approved = 1")->fetchColumn();
    $blockedCount     = (int) $db->query("SELECT COUNT(*) FROM companies WHERE approved = 0")->fetchColumn();

    // Acessos dos últimos 7 dias (views não implementadas ainda — retorna zeros)
    $accessData = [];
    for ($i = 6; $i >= 0; $i--) {
        $date = date('Y-m-d', strtotime("-$i days"));
        $accessData[] = ['date' => $date, 'count' => 0];
    }

    // Empresas recentes
    $stmt = $db->query("
        SELECT c.id, c.name, c.approved, c.createdAt, cat.name AS categoryName
        FROM companies c
        LEFT JOIN categories cat ON cat.id = c.categoryId
        ORDER BY c.createdAt DESC
        LIMIT 10
    ");
    $recentCompanies = $stmt->fetchAll();

    foreach ($recentCompanies as &$c) {
        $c['approved'] = (bool) $c['approved'];
    }

    respond(200, [
        'stats' => [
            'totalCompanies'  => $totalCompanies,
            'totalCategories' => $totalCategories,
            'approvedCount'   => $approvedCount,
            'blockedCount'    => $blockedCount,
        ],
        'accessData'      => $accessData,
        'recentCompanies' => $recentCompanies,
    ]);
}
