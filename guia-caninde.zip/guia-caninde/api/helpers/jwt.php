<?php
/**
 * JWT Helper - Implementação pura sem dependências externas
 * Guia Canindé
 *
 * Suporta apenas HS256 (HMAC-SHA256), suficiente para este projeto.
 */

function jwtEncode(array $payload): string {
    $header = base64UrlEncode(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));

    // Adiciona expiração automática
    $payload['iat'] = time();
    $payload['exp'] = time() + (int) JWT_EXPIRES;

    $encodedPayload = base64UrlEncode(json_encode($payload));
    $signature      = base64UrlEncode(
        hash_hmac('sha256', "$header.$encodedPayload", JWT_SECRET, true)
    );

    return "$header.$encodedPayload.$signature";
}

function jwtDecode(string $token): ?array {
    $parts = explode('.', $token);
    if (count($parts) !== 3) return null;

    [$header, $payload, $signature] = $parts;

    // Valida assinatura
    $expectedSig = base64UrlEncode(
        hash_hmac('sha256', "$header.$payload", JWT_SECRET, true)
    );
    if (!hash_equals($expectedSig, $signature)) return null;

    $data = json_decode(base64UrlDecode($payload), true);
    if (!$data) return null;

    // Valida expiração
    if (isset($data['exp']) && $data['exp'] < time()) return null;

    return $data;
}

function base64UrlEncode(string $data): string {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function base64UrlDecode(string $data): string {
    return base64_decode(strtr($data, '-_', '+/') . str_repeat('=', 3 - (3 + strlen($data)) % 4));
}
