<?php
/**
 * Helpers gerais da API
 * Guia Canindé
 */

/** Responde JSON com status HTTP e encerra */
function respond(int $status, mixed $data): void {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/** Responde erro JSON */
function respondError(int $status, string $message): void {
    respond($status, ['error' => $message]);
}

/** Gera UUID v4 */
function generateUuid(): string {
    $data    = random_bytes(16);
    $data[6] = chr(ord($data[6]) & 0x0f | 0x40); // versão 4
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80); // variante RFC 4122
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

/** Sanitiza string de input */
function sanitize(string $value): string {
    return trim(strip_tags($value));
}

/** Valida e retorna body JSON do request */
function getJsonBody(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

/** Formata empresa com média de avaliações */
function formatCompany(array $company): array {
    $company['approved']    = (bool) $company['approved'];
    $company['avgRating']   = $company['avgRating'] ? round((float) $company['avgRating'], 1) : null;
    $company['totalRatings'] = (int) ($company['totalRatings'] ?? 0);
    return $company;
}
