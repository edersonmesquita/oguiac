# 🗺️ Guia Canindé — Deploy PHP + MySQL

Sistema completo de diretório comercial convertido de Node.js/Next.js para **PHP puro + MySQL**, pronto para hospedagem compartilhada.

---

## 📁 Estrutura do Projeto

```
guia-caninde/
├── api/                        ← Backend PHP (API REST)
│   ├── index.php               ← Roteador único
│   ├── .htaccess
│   ├── config/
│   │   └── database.php        ← Conexão MySQL + constantes
│   ├── controllers/
│   │   ├── AuthController.php
│   │   ├── CompanyController.php
│   │   ├── CategoryController.php
│   │   ├── RatingController.php
│   │   └── DashboardController.php
│   ├── middleware/
│   │   └── auth.php            ← Validação JWT
│   └── helpers/
│       ├── jwt.php             ← JWT puro sem dependências
│       └── response.php        ← Helpers de resposta/UUID
│
├── public/                     ← Frontend (HTML/CSS/JS puro)
│   ├── index.html              ← SPA principal
│   ├── .htaccess               ← Roteamento SPA + /api/*
│   ├── manifest.json           ← PWA
│   └── assets/
│       ├── css/style.css
│       ├── js/app.js
│       ├── images/             ← Ícones PWA (adicione manualmente)
│       └── uploads/logos/      ← Logos das empresas (gerado automaticamente)
│
├── admin/                      ← Painel Administrativo
│   ├── index.html
│   └── assets/
│       ├── css/admin.css
│       └── js/admin.js
│
├── database/
│   ├── schema.sql              ← Criar tabelas MySQL
│   ├── export-to-mysql.js      ← Exportar dados do Prisma
│   └── reset-admin-password.php
│
├── .env.example                ← Modelo de variáveis de ambiente
├── .gitignore
└── README.md
```

---

## 🚀 Deploy Passo a Passo

### Pré-requisitos
- Hospedagem com PHP 8.0+ e MySQL 5.7+/8.0
- Acesso ao cPanel ou painel de controle
- Acesso FTP ou Gerenciador de Arquivos
- Git (opcional, para deploy automático)

---

### Passo 1 — Exportar dados do sistema atual

Na pasta do **backend Node.js original**:

```bash
# Copie o script de exportação para a pasta do backend
cp database/export-to-mysql.js ../backendGuiaCanind--main/

# Rode o script (precisa do Prisma configurado)
cd ../backendGuiaCanind--main
node export-to-mysql.js

# Será gerado: guia_caninde_data.sql
```

---

### Passo 2 — Criar banco de dados no cPanel

1. Acesse **cPanel → MySQL Databases**
2. Crie o banco: `usuario_guiacaninde` *(o prefixo é obrigatório no cPanel)*
3. Crie o usuário e defina a senha
4. Adicione o usuário ao banco com **Todos os privilégios**

---

### Passo 3 — Importar o banco

No **cPanel → phpMyAdmin**:

1. Selecione o banco criado
2. Clique em **Importar**
3. Importe `database/schema.sql` primeiro
4. Importe `guia_caninde_data.sql` depois (dados do sistema atual)

---

### Passo 4 — Configurar variáveis de ambiente

1. Copie `.env.example` para `.env`
2. Edite com as credenciais reais:

```env
DB_HOST=localhost
DB_NAME=usuario_guiacaninde
DB_USER=usuario_db
DB_PASS=sua_senha_real

JWT_SECRET=gere_uma_chave_forte_aqui_32chars_minimo
APP_URL=https://seudominio.com.br
ALLOWED_ORIGINS=https://seudominio.com.br
```

> 💡 **Gerar JWT_SECRET seguro:**
> ```bash
> # Linux/Mac:
> openssl rand -hex 32
> # Ou use: https://generate-secret.vercel.app/32
> ```

---

### Passo 5 — Upload dos arquivos

**Via cPanel Gerenciador de Arquivos ou FTP:**

```
Estrutura no servidor:
public_html/
├── index.html          ← de public/index.html
├── manifest.json       ← de public/manifest.json
├── .htaccess           ← de public/.htaccess
├── assets/             ← de public/assets/
├── uploads/            ← de public/uploads/
├── admin/              ← pasta admin/ completa
├── api/                ← pasta api/ completa
└── .env                ← seu .env configurado
```

**⚠️ Atenção:** O `.env` fica na raiz do `public_html`, não dentro de `api/`.

---

### Passo 6 — Definir senha do admin

```bash
# Via SSH (se disponível):
php public_html/database/reset-admin-password.php

# Ou acesse diretamente o admin e use as credenciais do seed:
# Usuário: admin
# Senha:   password   ← TROQUE IMEDIATAMENTE!
```

---

### Passo 7 — Configurar URL da API no frontend

Edite `public_html/index.html` e `public_html/admin/index.html`:

```html
<!-- Troque a linha: -->
window.API_BASE_URL = '/api';

<!-- Por (se o site estiver em subdiretório): -->
window.API_BASE_URL = 'https://seudominio.com.br/api';
```

---

### Passo 8 — Ativar HTTPS

No `public_html/.htaccess`, descomente as linhas:

```apache
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

---

## 🔗 URLs do sistema

| Página | URL |
|---|---|
| Site público | `https://seudominio.com.br/` |
| Categorias | `https://seudominio.com.br/#/categorias` |
| Buscar | `https://seudominio.com.br/#/buscar` |
| Cadastrar negócio | `https://seudominio.com.br/#/cadastrar` |
| Login empresa | `https://seudominio.com.br/#/empresa-login` |
| **Painel Admin** | `https://seudominio.com.br/admin/` |
| API health check | `https://seudominio.com.br/api/health` |

---

## 🔌 Endpoints da API

| Método | Endpoint | Descrição | Auth |
|---|---|---|---|
| GET | `/api/health` | Status da API | Não |
| GET | `/api/categories` | Lista categorias | Não |
| GET | `/api/companies` | Lista empresas | Não |
| GET | `/api/companies?search=X` | Busca empresas | Não |
| GET | `/api/companies?category=ID` | Filtra por categoria | Não |
| POST | `/api/companies` | Cadastra empresa | Não |
| POST | `/api/companies/upload-logo` | Upload de logo | Não |
| POST | `/api/auth/admin/login` | Login admin | Não |
| POST | `/api/auth/company/login` | Login empresa | Não |
| GET | `/api/dashboard` | Stats do painel | Admin |
| PATCH | `/api/companies/:id/approve` | Liberar/bloquear | Admin |
| PUT | `/api/companies/:id` | Editar empresa | Admin/Empresa |
| DELETE | `/api/companies/:id` | Excluir empresa | Admin |

---

## 🐛 Troubleshooting

### "500 Internal Server Error" na API
- Verifique se o `.env` está na raiz do `public_html`
- Confirme as credenciais do banco no `.env`
- Verifique os logs: cPanel → Logs de Erros

### "CORS error" no console do browser
- Ajuste `ALLOWED_ORIGINS` no `.env` com o domínio correto
- Verifique se o `.htaccess` da API está ativo

### API retorna HTML em vez de JSON
- O `mod_rewrite` pode estar desativado
- Confirme que o arquivo `api/.htaccess` foi enviado

### Uploads de logo não funcionam
- Verifique permissões: `public/uploads/logos/` deve ser `755`
- Confirme que a pasta existe no servidor

### Login admin não funciona
- Execute `reset-admin-password.php` para redefinir a senha
- Confirme que o `JWT_SECRET` está no `.env`

---

## 🔒 Checklist de Segurança para Produção

- [ ] Trocar a senha padrão do admin (`password`)
- [ ] Definir `JWT_SECRET` único e forte (32+ chars)
- [ ] Ativar HTTPS e redirecionar HTTP → HTTPS
- [ ] Ajustar `ALLOWED_ORIGINS` para seu domínio específico
- [ ] Verificar que `.env` não é acessível publicamente
- [ ] Permissões corretas: arquivos `644`, pastas `755`
- [ ] Desativar `display_errors` no PHP em produção

---

## 📦 Deploy via GitHub Actions (opcional)

Crie `.github/workflows/deploy.yml`:

```yaml
name: Deploy para Hospedagem

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3

      - name: Deploy via FTP
        uses: SamKirkland/FTP-Deploy-Action@v4.3.4
        with:
          server: ${{ secrets.FTP_HOST }}
          username: ${{ secrets.FTP_USER }}
          password: ${{ secrets.FTP_PASS }}
          local-dir: ./
          server-dir: /public_html/
          exclude: |
            **/.git*
            **/.git*/**
            **/node_modules/**
            .env.example
            database/export-to-mysql.js
            README.md
```

**Secrets necessários no GitHub:**
- `FTP_HOST` — host FTP da hospedagem
- `FTP_USER` — usuário FTP
- `FTP_PASS` — senha FTP

---

## ✅ Tecnologias

| Camada | Original | Convertido |
|---|---|---|
| Backend | Node.js + TypeScript + Express | PHP 8.0+ puro |
| ORM/DB | Prisma + PostgreSQL/SQLite | PDO + MySQL |
| Auth | jsonwebtoken (npm) | JWT implementado em PHP puro |
| Frontend | Next.js 14 + React | HTML5 + CSS3 + JS vanilla |
| Upload | UploadThing (SaaS) | PHP `move_uploaded_file` local |
| Deploy | Vercel/Railway | Qualquer hospedagem cPanel |
