#!/usr/bin/env node
/**
 * export-to-mysql.js
 * Exporta dados do banco Node.js/Prisma para SQL compatível com MySQL
 *
 * USO:
 *   1. Na pasta do backend Node original:
 *      node export-to-mysql.js
 *
 *   2. O arquivo guia_caninde_data.sql será gerado
 *   3. Importe no MySQL: mysql -u user -p guia_caninde < guia_caninde_data.sql
 *
 * INSTALAÇÃO (se precisar):
 *   npm install @prisma/client
 */

const { PrismaClient } = require('@prisma/client');
const fs = require('fs');
const path = require('path');

const prisma = new PrismaClient();

function escapeSql(val) {
    if (val === null || val === undefined) return 'NULL';
    if (typeof val === 'boolean') return val ? '1' : '0';
    if (typeof val === 'number') return val;
    if (val instanceof Date) return `'${val.toISOString().slice(0, 19).replace('T', ' ')}'`;
    // Escapa aspas simples
    return `'${String(val).replace(/\\/g, '\\\\').replace(/'/g, "\\'")}'`;
}

function row(table, data) {
    const cols = Object.keys(data).map(k => `\`${k}\``).join(', ');
    const vals = Object.values(data).map(escapeSql).join(', ');
    return `INSERT IGNORE INTO \`${table}\` (${cols}) VALUES (${vals});`;
}

async function main() {
    console.log('🔄 Exportando dados do Prisma para MySQL...\n');

    let sql = `-- Guia Canindé — Export de dados
-- Gerado em: ${new Date().toISOString()}
-- Importe APÓS criar o schema: mysql -u user -p guia_caninde < guia_caninde_data.sql

SET FOREIGN_KEY_CHECKS = 0;
SET NAMES utf8mb4;

`;

    // ---- CATEGORIAS ----
    const categories = await prisma.category.findMany({ orderBy: { createdAt: 'asc' } });
    console.log(`✅ Categorias: ${categories.length}`);
    sql += `-- CATEGORIAS\n`;
    for (const c of categories) {
        sql += row('categories', {
            id: c.id, name: c.name,
            description: c.description || null,
            createdAt: c.createdAt, updatedAt: c.updatedAt,
        }) + '\n';
    }
    sql += '\n';

    // ---- EMPRESAS ----
    const companies = await prisma.company.findMany({ orderBy: { createdAt: 'asc' } });
    console.log(`✅ Empresas: ${companies.length}`);
    sql += `-- EMPRESAS\n`;
    for (const c of companies) {
        sql += row('companies', {
            id: c.id, name: c.name, whatsapp: c.whatsapp,
            address: c.address, logo: c.logo || null,
            instagram: c.instagram || null, facebook: c.facebook || null,
            youtube: c.youtube || null, website: c.website || null,
            email: c.email || null, password: c.password || null,
            description: c.description || null,
            approved: c.approved ?? 1,
            categoryId: c.categoryId, planId: c.planId || null,
            createdAt: c.createdAt, updatedAt: c.updatedAt,
        }) + '\n';
    }
    sql += '\n';

    // ---- RATINGS ----
    const ratings = await prisma.rating.findMany({ orderBy: { createdAt: 'asc' } });
    console.log(`✅ Avaliações: ${ratings.length}`);
    sql += `-- AVALIAÇÕES\n`;
    for (const r of ratings) {
        sql += row('ratings', {
            id: r.id, stars: r.stars,
            companyId: r.companyId, userId: r.userId || null,
            createdAt: r.createdAt, updatedAt: r.updatedAt,
        }) + '\n';
    }
    sql += '\n';

    // ---- ADMINS ----
    const admins = await prisma.admin?.findMany?.({ orderBy: { createdAt: 'asc' } }) ?? [];
    if (admins.length) {
        console.log(`✅ Admins: ${admins.length}`);
        sql += `-- ADMINS\n`;
        for (const a of admins) {
            sql += row('admins', {
                id: a.id, username: a.username,
                password: a.password, name: a.name,
                createdAt: a.createdAt, updatedAt: a.updatedAt,
            }) + '\n';
        }
        sql += '\n';
    }

    sql += `SET FOREIGN_KEY_CHECKS = 1;\n`;

    const outFile = path.join(__dirname, 'guia_caninde_data.sql');
    fs.writeFileSync(outFile, sql, 'utf8');

    console.log(`\n✅ Exportado com sucesso: ${outFile}`);
    console.log(`   Categorias: ${categories.length}`);
    console.log(`   Empresas:   ${companies.length}`);
    console.log(`   Avaliações: ${ratings.length}`);
    console.log(`\n📌 Próximo passo:`);
    console.log(`   mysql -u SEU_USUARIO -p guia_caninde < guia_caninde_data.sql`);
}

main()
    .catch(e => { console.error('❌ Erro:', e.message); process.exit(1); })
    .finally(() => prisma.$disconnect());
