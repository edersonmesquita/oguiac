-- ============================================================
-- Guia Canindé - Schema MySQL
-- Migrado do Prisma (PostgreSQL) para MySQL
-- ============================================================

CREATE DATABASE IF NOT EXISTS guia_caninde CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE guia_caninde;

-- Tabela de admins
CREATE TABLE IF NOT EXISTS admins (
    id          VARCHAR(36) NOT NULL PRIMARY KEY,
    username    VARCHAR(100) NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,
    name        VARCHAR(150) NOT NULL,
    createdAt   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de usuários (clientes que avaliam)
CREATE TABLE IF NOT EXISTS users (
    id          VARCHAR(36) NOT NULL PRIMARY KEY,
    email       VARCHAR(255) NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,
    name        VARCHAR(150) NOT NULL,
    createdAt   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de planos
CREATE TABLE IF NOT EXISTS plans (
    id          VARCHAR(36) NOT NULL PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    features    JSON NOT NULL,           -- array de strings (era String[] no Prisma)
    price       DECIMAL(10,2) NOT NULL,
    createdAt   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de categorias
CREATE TABLE IF NOT EXISTS categories (
    id          VARCHAR(36) NOT NULL PRIMARY KEY,
    name        VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    createdAt   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de empresas
CREATE TABLE IF NOT EXISTS companies (
    id          VARCHAR(36) NOT NULL PRIMARY KEY,
    name        VARCHAR(255) NOT NULL,
    whatsapp    VARCHAR(20) NOT NULL,
    address     VARCHAR(500) NOT NULL,
    logo        VARCHAR(500),
    instagram   VARCHAR(255),
    facebook    VARCHAR(255),
    youtube     VARCHAR(255),
    website     VARCHAR(255),
    email       VARCHAR(255),
    password    VARCHAR(255),
    description VARCHAR(300),
    approved    TINYINT(1) NOT NULL DEFAULT 1,
    categoryId  VARCHAR(36) NOT NULL,
    planId      VARCHAR(36),
    createdAt   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_company_category FOREIGN KEY (categoryId) REFERENCES categories(id) ON DELETE RESTRICT,
    CONSTRAINT fk_company_plan     FOREIGN KEY (planId)     REFERENCES plans(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de avaliações
CREATE TABLE IF NOT EXISTS ratings (
    id          VARCHAR(36) NOT NULL PRIMARY KEY,
    stars       TINYINT NOT NULL CHECK (stars BETWEEN 1 AND 5),
    companyId   VARCHAR(36) NOT NULL,
    userId      VARCHAR(36),
    createdAt   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_rating_company FOREIGN KEY (companyId) REFERENCES companies(id) ON DELETE CASCADE,
    CONSTRAINT fk_rating_user    FOREIGN KEY (userId)    REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Índices para performance
-- ============================================================
CREATE INDEX idx_companies_category ON companies(categoryId);
CREATE INDEX idx_companies_approved ON companies(approved);
CREATE INDEX idx_companies_name     ON companies(name);
CREATE INDEX idx_ratings_company    ON ratings(companyId);

-- ============================================================
-- Seed: Admin padrão (senha: admin123 - TROQUE EM PRODUÇÃO!)
-- Hash bcrypt de 'admin123'
-- ============================================================
INSERT INTO admins (id, username, password, name, createdAt, updatedAt) VALUES (
    'adm-00000000-0000-0000-0000-000000000001',
    'admin',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- senha: password
    'Administrador',
    NOW(),
    NOW()
) ON DUPLICATE KEY UPDATE username=username;

-- ============================================================
-- Seed: Categorias iniciais (espelhando o sistema original)
-- ============================================================
INSERT INTO categories (id, name, createdAt, updatedAt) VALUES
    (UUID(), 'Restaurantes',       NOW(), NOW()),
    (UUID(), 'Saúde',              NOW(), NOW()),
    (UUID(), 'Comércio',           NOW(), NOW()),
    (UUID(), 'Academia',           NOW(), NOW()),
    (UUID(), 'Auto Peças',         NOW(), NOW()),
    (UUID(), 'Beleza',             NOW(), NOW()),
    (UUID(), 'Construção',         NOW(), NOW()),
    (UUID(), 'Conveniência',       NOW(), NOW()),
    (UUID(), 'Taxi',               NOW(), NOW()),
    (UUID(), 'Pizzarias',          NOW(), NOW()),
    (UUID(), 'Hamburguerias',      NOW(), NOW()),
    (UUID(), 'Pastelarias',        NOW(), NOW()),
    (UUID(), 'Moto Taxi',          NOW(), NOW()),
    (UUID(), 'Marmitarias',        NOW(), NOW()),
    (UUID(), 'Clinicas Dentarias', NOW(), NOW()),
    (UUID(), 'Farmácias',          NOW(), NOW()),
    (UUID(), 'Serviços em Geral',  NOW(), NOW()),
    (UUID(), 'Educação',           NOW(), NOW()),
    (UUID(), 'Transporte',         NOW(), NOW()),
    (UUID(), 'Hospedagem',         NOW(), NOW())
ON DUPLICATE KEY UPDATE name=name;
