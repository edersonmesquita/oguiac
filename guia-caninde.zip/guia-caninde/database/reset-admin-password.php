#!/usr/bin/env php
<?php
/**
 * reset-admin-password.php
 * Utilitário para resetar a senha do admin via linha de comando
 *
 * USO (na raiz do projeto):
 *   php database/reset-admin-password.php
 *   php database/reset-admin-password.php novasenha123
 */

// Carrega configurações
require_once __DIR__ . '/../api/config/database.php';

$newPassword = $argv[1] ?? null;

if (!$newPassword) {
    echo "Digite a nova senha para o admin: ";
    $newPassword = trim(fgets(STDIN));
}

if (strlen($newPassword) < 6) {
    die("❌ Senha muito curta (mínimo 6 caracteres)\n");
}

$hash = password_hash($newPassword, PASSWORD_BCRYPT);
$db   = getDB();

// Verifica se admin existe
$stmt = $db->query("SELECT id, username FROM admins LIMIT 1");
$admin = $stmt->fetch();

if (!$admin) {
    // Cria admin padrão
    $id = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000, mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
    $db->prepare("INSERT INTO admins (id, username, password, name, createdAt, updatedAt) VALUES (?, 'admin', ?, 'Administrador', NOW(), NOW())")
       ->execute([$id, $hash]);
    echo "✅ Admin criado com sucesso!\n";
    echo "   Usuário: admin\n";
    echo "   Senha:   $newPassword\n";
} else {
    $db->prepare("UPDATE admins SET password = ?, updatedAt = NOW() WHERE id = ?")
       ->execute([$hash, $admin['id']]);
    echo "✅ Senha atualizada com sucesso!\n";
    echo "   Usuário: {$admin['username']}\n";
    echo "   Senha:   $newPassword\n";
}
